package com.chesscoach

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val reqProj = 77
    private val reqNotif = 78
    private var notifAsked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(48, 96, 48, 48)
        val tv = TextView(this)
        tv.textSize = 16f
        tv.text = "Chess Coach\n\n" +
            "۱) روی «شروع» بزن و دسترسی‌ها را بده (نمایش روی برنامه‌ها، ضبط صفحه ← «کل صفحه / Entire screen»).\n" +
            "۲) برو داخل بازی شطرنج؛ پنل کوچک روی صفحه است.\n" +
            "۳) رنگ خودت را انتخاب کن، یک بار «کالیبره» را بزن، بعد «شروع».\n"
        val btn = Button(this)
        btn.text = "شروع"
        btn.setOnClickListener { go() }
        root.addView(tv)
        root.addView(btn)
        setContentView(root)
    }

    private fun go() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "دسترسی «نمایش روی سایر برنامه‌ها» را روشن کن و دوباره شروع بزن", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !notifAsked &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifAsked = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqProj)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqNotif) go()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqProj && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CoachService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
